struct Movie {
    char movieName[100];
    int duration; 
    char category[5]; 
    int ticketCost;
};

struct Movie GetMovieDetails();
char* GetCircleDetails();
int CalculateTicketCost(struct Movie* m, char circle[]);
#include <stdio.h>
#include <string.h>
#include "movie.h"

struct Movie GetMovieDetails() {
    struct Movie m;
    printf("Enter movie name: ");
    scanf_s("%s", m.movieName, sizeof(m.movieName));
    printf("Enter movie duration: ");
    scanf_s("%d", &m.duration);
    printf("Enter movie category (2D/3D): ");
    scanf_s("%s", &m.category,sizeof(m.category));
    return m;
    m.ticketCost = 0;
}

char* GetCircleDetails() {
    static char circle[10];
    printf("Enter circle (gold/silver): ");
    scanf_s("%s", circle);
    return circle;
}

int CalculateTicketCost(struct Movie* m,char circle[]) 
{
    if (strcmp(m->category, "2D") != 0 && strcmp(m->category, "3D") != 0) {
        return -1;
    }

    if (strcmp(circle, "gold") == 0 && strcmp(m->category, "2D") == 0) {
        m->ticketCost = 300;
    }
    else if (strcmp(circle, "gold") == 0 && strcmp(m->category, "3D") == 0) {
        m->ticketCost = 500;
    }
    else if (strcmp(circle, "silver") == 0 && strcmp(m->category, "2D") == 0) {
        m->ticketCost = 250;
    }
    else if (strcmp(circle, "silver") == 0 && strcmp(m->category, "3D") == 0) {
        m->ticketCost = 450;
    }
    else {
        return -2;
    }

    return 0;
}

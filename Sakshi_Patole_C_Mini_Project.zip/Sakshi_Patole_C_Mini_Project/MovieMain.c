#include <stdio.h>
#include "Movie.h"

int main() {
    struct Movie m = GetMovieDetails();
    char* circle = GetCircleDetails();

    int cal = CalculateTicketCost(&m, circle);

    if (cal == 0) {
        printf("The ticket cost is Rs. %d\n", m.ticketCost);
    }
    else if (cal == -1) {
        printf("Sorry, there is no %s type of category in the theatre.\n", (m.category == 1 ? "2D" : "3D"));
    }
    else if (cal == -2) {
        printf("Sorry, the circle is invalid.\n");
    }
    else if (cal == -3 ) {
        printf("Sorry, both circle and category are invalid.\n");
    }

    return 0;
}
